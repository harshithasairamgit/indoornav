export interface SearchData {
	query: string,
	results: any[]
}