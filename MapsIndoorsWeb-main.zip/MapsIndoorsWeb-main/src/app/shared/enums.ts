export enum UnitSystem {
    Imperial = 'imperial',
    Metric = 'metric'
}
