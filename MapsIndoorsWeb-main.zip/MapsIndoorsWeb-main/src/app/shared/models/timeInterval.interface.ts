export interface TimeInterval {
    start: Date,
    end: Date
}
