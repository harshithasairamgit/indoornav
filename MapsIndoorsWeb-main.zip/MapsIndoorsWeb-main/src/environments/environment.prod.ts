export const environment = {
    production: true,
    version: '5.15.0',
    v: require('../../package.json').version,
    sdkUrl: 'https://app.mapsindoors.com/mapsindoors/js/sdk/4.14.1/mapsindoors-4.14.1.js.gz',
    sentryDsn: '',
    suggestedSolutionId: 'demo'
};
